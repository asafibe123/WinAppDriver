﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MouseWheelDemo
{
    public partial class Form1 : Form
    {
        int _totalDelta = 0;

        public Form1()
        {
            InitializeComponent();
            this.MouseWheel += Form_MouseWheel;
        }

        void Form_MouseWheel(object sender, MouseEventArgs e)
        {
            _totalDelta = _totalDelta + e.Delta;
            DeltaLabel.Text = e.Delta.ToString();
            TotalDeltaLabel.Text = _totalDelta.ToString();
            LinesLabel.Text = (SystemInformation.MouseWheelScrollLines * _totalDelta / 120).ToString();
        }
    }
}
